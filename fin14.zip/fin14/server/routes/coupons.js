const express = require('express');
const router = express.Router();
const db = require('../database/db');
const { authenticateToken } = require('../middleware/auth');

router.post('/validate', authenticateToken, async (req, res) => {
  try {
    const { code, subtotal } = req.body;

    if (!code) {
      return res.status(400).json({ error: 'Código do cupom é obrigatório' });
    }

    const result = await db.query(
      `SELECT * FROM coupons 
       WHERE code = $1 
       AND is_active = true 
       AND (valid_from IS NULL OR valid_from <= NOW())
       AND (valid_until IS NULL OR valid_until >= NOW())
       AND (usage_limit IS NULL OR times_used < usage_limit)`,
      [code]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Cupom inválido ou expirado' });
    }

    const coupon = result.rows[0];

    if (coupon.min_purchase_amount && subtotal < coupon.min_purchase_amount) {
      return res.status(400).json({ 
        error: `Valor mínimo de compra: R$ ${coupon.min_purchase_amount.toFixed(2)}` 
      });
    }

    let discount = 0;
    if (coupon.discount_type === 'percentage') {
      discount = (subtotal * coupon.discount_value) / 100;
      if (coupon.max_discount_amount) {
        discount = Math.min(discount, coupon.max_discount_amount);
      }
    } else {
      discount = coupon.discount_value;
    }

    res.json({
      valid: true,
      coupon: {
        code: coupon.code,
        description: coupon.description,
        discount_type: coupon.discount_type,
        discount_value: coupon.discount_value
      },
      discount: Math.round(discount * 100) / 100
    });
  } catch (error) {
    console.error('Error validating coupon:', error);
    res.status(500).json({ error: 'Erro ao validar cupom' });
  }
});

module.exports = router;
