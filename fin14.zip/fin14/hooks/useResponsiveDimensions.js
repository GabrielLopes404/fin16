import { useState, useEffect } from 'react';
import { Dimensions, Platform } from 'react-native';
import { Breakpoints, Spacing, FontSizes } from '../constants/theme';

export function useResponsiveDimensions() {
  const [dimensions, setDimensions] = useState({
    window: Dimensions.get('window'),
    screen: Dimensions.get('screen'),
  });

  useEffect(() => {
    const subscription = Dimensions.addEventListener('change', ({ window, screen }) => {
      setDimensions({ window, screen });
    });

    return () => subscription?.remove();
  }, []);

  const { width, height } = dimensions.window;

  const breakpoint = 
    width >= Breakpoints.desktop ? 'desktop' :
    width >= Breakpoints.tablet ? 'tablet' :
    width >= Breakpoints.large ? 'large' :
    width >= Breakpoints.medium ? 'medium' : 'small';

  const isSmall = breakpoint === 'small';
  const isMedium = breakpoint === 'medium';
  const isLarge = breakpoint === 'large';
  const isTablet = breakpoint === 'tablet';
  const isDesktop = breakpoint === 'desktop';
  
  const isMobile = isSmall || isMedium || isLarge;
  const isLandscape = width > height;
  const isPortrait = height > width;

  const spacing = {
    xs: isSmall ? Spacing.xs * 0.8 : Spacing.xs,
    sm: isSmall ? Spacing.sm * 0.9 : Spacing.sm,
    md: isSmall ? Spacing.md * 0.9 : Spacing.md,
    lg: isSmall ? Spacing.lg * 0.9 : Spacing.lg,
    xl: isSmall ? Spacing.xl * 0.9 : Spacing.xl,
    xxl: isSmall ? Spacing.xxl * 0.9 : Spacing.xxl,
    xxxl: isSmall ? Spacing.xxxl * 0.9 : Spacing.xxxl,
  };

  const fontSize = {
    xs: isSmall ? FontSizes.xs * 0.95 : FontSizes.xs,
    sm: isSmall ? FontSizes.sm * 0.95 : FontSizes.sm,
    md: isSmall ? FontSizes.md * 0.95 : FontSizes.md,
    lg: isSmall ? FontSizes.lg * 0.95 : FontSizes.lg,
    xl: isSmall ? FontSizes.xl * 0.95 : FontSizes.xl,
    xxl: isSmall ? FontSizes.xxl * 0.95 : FontSizes.xxl,
    xxxl: isSmall ? FontSizes.xxxl * 0.95 : FontSizes.xxxl,
    huge: isSmall ? FontSizes.huge * 0.95 : FontSizes.huge,
    massive: isSmall ? FontSizes.massive * 0.95 : FontSizes.massive,
  };

  const scale = (size) => {
    const baseWidth = 375;
    return (width / baseWidth) * size;
  };

  const moderateScale = (size, factor = 0.5) => {
    const baseWidth = 375;
    return size + (scale(size) - size) * factor;
  };

  const gridColumns = 
    isDesktop ? 4 :
    isTablet ? 3 :
    isLarge ? 2 :
    2;

  const cardWidth = width > 768 ? (width - Spacing.xl * 3) / 2 : width - Spacing.lg * 2;

  return {
    width,
    height,
    breakpoint,
    isSmall,
    isMedium,
    isLarge,
    isTablet,
    isDesktop,
    isMobile,
    isLandscape,
    isPortrait,
    spacing,
    fontSize,
    scale,
    moderateScale,
    gridColumns,
    cardWidth,
    platform: Platform.OS,
    isIOS: Platform.OS === 'ios',
    isAndroid: Platform.OS === 'android',
    isWeb: Platform.OS === 'web',
  };
}

export function useOrientation() {
  const { isLandscape, isPortrait } = useResponsiveDimensions();
  return { isLandscape, isPortrait };
}

export function useBreakpoint() {
  const { breakpoint, isSmall, isMedium, isLarge, isTablet, isDesktop, isMobile } = useResponsiveDimensions();
  return { breakpoint, isSmall, isMedium, isLarge, isTablet, isDesktop, isMobile };
}
