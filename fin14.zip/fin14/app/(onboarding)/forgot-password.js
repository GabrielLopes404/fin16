import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, KeyboardAvoidingView, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Input from '../../components/Input';
import Button from '../../components/Button';
import { Colors, FontSizes, Spacing, FontWeights } from '../../constants/theme';

export default function ForgotPasswordScreen() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleResetPassword = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSent(true);
    }, 1500);
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <View style={styles.content}>
          <TouchableOpacity
            onPress={() => router.back()}
            style={styles.backButton}
          >
            <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
          </TouchableOpacity>

          <View style={styles.header}>
            <View style={styles.iconContainer}>
              <Ionicons 
                name={sent ? "checkmark-circle" : "lock-closed"} 
                size={48} 
                color={sent ? Colors.success : Colors.primary} 
              />
            </View>
            <Text style={styles.title}>
              {sent ? 'Email enviado!' : 'Esqueceu a senha?'}
            </Text>
            <Text style={styles.subtitle}>
              {sent 
                ? 'Enviamos um link de recuperação para o seu email. Verifique sua caixa de entrada.'
                : 'Digite seu email e enviaremos um link para redefinir sua senha.'
              }
            </Text>
          </View>

          {!sent && (
            <View style={styles.form}>
              <Input
                label="Email"
                value={email}
                onChangeText={setEmail}
                placeholder="seu@email.com"
                keyboardType="email-address"
                icon={<Ionicons name="mail-outline" size={20} color={Colors.textSecondary} />}
              />

              <Button
                title="Enviar link de recuperação"
                onPress={handleResetPassword}
                loading={loading}
                style={{ marginTop: Spacing.xl }}
              />
            </View>
          )}

          {sent && (
            <View style={styles.sentActions}>
              <Button
                title="Voltar para login"
                onPress={() => router.push('/(onboarding)/login')}
              />

              <TouchableOpacity 
                onPress={() => setSent(false)}
                style={styles.resendButton}
              >
                <Text style={styles.resendText}>Não recebeu o email? Reenviar</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.backgroundLight,
  },
  keyboardView: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: Spacing.xl,
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    marginTop: Spacing.md,
  },
  header: {
    alignItems: 'center',
    marginTop: Spacing.xxxl,
    marginBottom: Spacing.xxxl,
  },
  iconContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: Colors.primary + '15',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.xl,
  },
  title: {
    fontSize: FontSizes.xxxl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: Spacing.md,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 24,
    paddingHorizontal: Spacing.lg,
  },
  form: {
    marginBottom: Spacing.xl,
  },
  sentActions: {
    gap: Spacing.lg,
  },
  resendButton: {
    alignSelf: 'center',
    paddingVertical: Spacing.md,
  },
  resendText: {
    fontSize: FontSizes.md,
    color: Colors.primary,
    fontWeight: FontWeights.semibold,
  },
});
