import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../constants/theme';

function SettingItem({ title, description, value, onValueChange, icon }) {
  return (
    <View style={styles.settingItem}>
      <View style={styles.settingLeft}>
        <View style={styles.settingIcon}>
          <Ionicons name={icon} size={24} color={Colors.primary} />
        </View>
        <View style={styles.settingText}>
          <Text style={styles.settingTitle}>{title}</Text>
          {description && <Text style={styles.settingDescription}>{description}</Text>}
        </View>
      </View>
      <Switch
        value={value}
        onValueChange={onValueChange}
        trackColor={{ false: Colors.border, true: Colors.primary + '50' }}
        thumbColor={value ? Colors.primary : Colors.backgroundLight}
      />
    </View>
  );
}

export default function NotificationSettingsScreen() {
  const router = useRouter();
  
  const [pushEnabled, setPushEnabled] = useState(true);
  const [emailEnabled, setEmailEnabled] = useState(true);
  const [smsEnabled, setSmsEnabled] = useState(false);
  
  const [ordersEnabled, setOrdersEnabled] = useState(true);
  const [promotionsEnabled, setPromotionsEnabled] = useState(true);
  const [appointmentsEnabled, setAppointmentsEnabled] = useState(true);
  const [newsEnabled, setNewsEnabled] = useState(false);
  const [loyaltyEnabled, setLoyaltyEnabled] = useState(true);
  const [reviewsEnabled, setReviewsEnabled] = useState(true);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
          activeOpacity={0.7}
        >
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Notificações</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.sectionTitle}>Canais de notificação</Text>
        <View style={styles.card}>
          <SettingItem
            title="Notificações Push"
            description="Receba alertas no seu celular"
            value={pushEnabled}
            onValueChange={setPushEnabled}
            icon="phone-portrait-outline"
          />
          <View style={styles.divider} />
          <SettingItem
            title="E-mail"
            description="Receba notificações por e-mail"
            value={emailEnabled}
            onValueChange={setEmailEnabled}
            icon="mail-outline"
          />
          <View style={styles.divider} />
          <SettingItem
            title="SMS"
            description="Receba mensagens de texto"
            value={smsEnabled}
            onValueChange={setSmsEnabled}
            icon="chatbubble-outline"
          />
        </View>

        <Text style={styles.sectionTitle}>Tipos de notificação</Text>
        <View style={styles.card}>
          <SettingItem
            title="Pedidos"
            description="Status de pedidos e entregas"
            value={ordersEnabled}
            onValueChange={setOrdersEnabled}
            icon="cart-outline"
          />
          <View style={styles.divider} />
          <SettingItem
            title="Promoções"
            description="Ofertas e descontos especiais"
            value={promotionsEnabled}
            onValueChange={setPromotionsEnabled}
            icon="pricetag-outline"
          />
          <View style={styles.divider} />
          <SettingItem
            title="Agendamentos"
            description="Lembretes de serviços agendados"
            value={appointmentsEnabled}
            onValueChange={setAppointmentsEnabled}
            icon="calendar-outline"
          />
          <View style={styles.divider} />
          <SettingItem
            title="Novidades"
            description="Novos produtos e lojas"
            value={newsEnabled}
            onValueChange={setNewsEnabled}
            icon="sparkles-outline"
          />
          <View style={styles.divider} />
          <SettingItem
            title="Fidelidade"
            description="Pontos e recompensas"
            value={loyaltyEnabled}
            onValueChange={setLoyaltyEnabled}
            icon="star-outline"
          />
          <View style={styles.divider} />
          <SettingItem
            title="Avaliações"
            description="Pedidos de avaliação"
            value={reviewsEnabled}
            onValueChange={setReviewsEnabled}
            icon="chatbubble-ellipses-outline"
          />
        </View>

        <View style={styles.infoBox}>
          <Ionicons name="information-circle" size={24} color={Colors.info} />
          <Text style={styles.infoText}>
            Você pode desativar todas as notificações nas configurações do seu dispositivo
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    backgroundColor: Colors.backgroundLight,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  backButton: {
    padding: Spacing.sm,
  },
  headerTitle: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    flex: 1,
    marginLeft: Spacing.md,
  },
  placeholder: {
    width: 40,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: Spacing.lg,
  },
  sectionTitle: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.textSecondary,
    marginBottom: Spacing.md,
    marginTop: Spacing.lg,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  card: {
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
    ...Shadows.small,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: Spacing.lg,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    marginRight: Spacing.md,
  },
  settingIcon: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.primary + '10',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Spacing.md,
  },
  settingText: {
    flex: 1,
  },
  settingTitle: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  settingDescription: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  divider: {
    height: 1,
    backgroundColor: Colors.border,
    marginLeft: Spacing.lg + 48 + Spacing.md,
  },
  infoBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.info + '10',
    borderRadius: BorderRadius.md,
    padding: Spacing.md,
    marginTop: Spacing.xl,
    gap: Spacing.md,
  },
  infoText: {
    flex: 1,
    fontSize: FontSizes.sm,
    color: Colors.info,
    lineHeight: 20,
  },
});
